const saudacao = require('./meuModulo'); // Importando o módulo

const mensagem = saudacao('Lucas'); // Executando a função
console.log(mensagem);